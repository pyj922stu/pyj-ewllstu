# IDEA 你不知道的小技巧

1. 快速打开 `MAVEN` 设置界面

   ![](http://images.atomblogs.com/atom/20190901204212.png?img)

2. 快速打开 `Plugin` 页面

   ![](http://images.atomblogs.com/atom/20190901204428.png?img)

3. 有了 `IDEA` 我就有了 `ssh` 远程工具 

   可能大部分人都不知道 `idea` 还有 `ssh` 的功能, 平常可能都是依靠一些外部工具来连接服务器比如 `xshell`, `putty` 之类的, 但每次需要操作服务器时, 还需要切换到另外一个软件, 这样才能操作.

     

   其实 `idea`  默认就提供了这样的功能

   ![](http://images.atomblogs.com/atom/20190909001008.png?img)

   如图选择 `start ssh session`

   

   ![](http://images.atomblogs.com/atom/20190909001355.png?img)

   在上图中填入 服务器相关信息

   

   ​	![](http://images.atomblogs.com/atom/20190909001244.png?img)

   上图中展示的是`IDEA`中两个非常棒的内置功能，可以在`Tools -> Start SSH session`中开启远程服务器的终端，在`IDEA`下方可以执行远程指令；也可以在`Tools -> Deployment ->Browse Remote Host`中展开如图右侧的结构，可视化地浏览服务器上的文件列表，检查应用是否部署成功。

   

4. 有了 `IDEA` 我就有了 `postman` 

   可能在平常的  `web` 开发中, 测试接口是必备的事, 大家可能使用诸如 `postman` `google 插件 Restlet Client` 或者 直接使用 `swagger` , 但是你可能不知道 其实 `idea `也内置了这样的功能

   ![](http://images.atomblogs.com/atom/20190909001701.png?img)



有了 IDEA, 我就有了 `TODO LIST` 



有了`IDEA`, 我就有了 `Navicat`



`ctrl + ~` 装逼必备

